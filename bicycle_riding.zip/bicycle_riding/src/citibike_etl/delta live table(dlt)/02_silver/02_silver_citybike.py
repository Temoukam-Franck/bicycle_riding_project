# Databricks notebook source
from pyspark import pipelines as dp
from pyspark.sql.functions import *

# COMMAND ----------

@dp.materialized_view(name = "silver_jc_citybike")
def silver_jc_citybike():
  df_bronze = dp.read("bronze_jc_citybike")

  df_silver = df_bronze.withColumn("trip_duration_mins",(unix_timestamp(col("ended_at"))-unix_timestamp(col("started_at")))/60)\
                        .withColumn("trip_start_date",to_date(col("started_at")))\
                        .select("ride_id","trip_start_date","started_at","ended_at","start_station_name","end_station_name","trip_duration_mins")
  return df_silver
  