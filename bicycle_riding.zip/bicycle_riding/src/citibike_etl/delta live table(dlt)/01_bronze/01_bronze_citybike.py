# Databricks notebook source
from pyspark import pipelines as dp
from pyspark.sql.types import *



# COMMAND ----------


    catalog = spark.conf.get("catalog")

# COMMAND ----------

schema = StructType([
    StructField("ride_id", StringType(), True),
    StructField("rideable_type", StringType(), True),
    StructField("started_at", TimestampType(), True),
    StructField("ended_at", TimestampType(), True),
    StructField("start_station_name", StringType(), True),
    StructField("start_station_id", StringType(), True),
    StructField("end_station_name", StringType(), True),
    StructField("end_station_id", StringType(), True),
    StructField("start_lat", DecimalType(), True),
    StructField("start_lng", DecimalType(), True),
    StructField("end_lat", DecimalType(), True),
    StructField("end_lng", DecimalType(), True),
    StructField("member_casual", StringType(), True),
])

# COMMAND ----------

@dp.materialized_view(name = "bronze_jc_citybike")
def bronze_jc_citybike():
  df = spark.read.format("csv")\
      .option("header", True)\
      .option("schema", schema)\
      .option("path", f"/Volumes/{catalog}/00_landing/source_citybike_data")\
      .load()
  return df