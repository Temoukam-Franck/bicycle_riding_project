# Databricks notebook source
from pyspark import pipelines as dp
from pyspark.sql.functions import *

# COMMAND ----------

@dp.materialized_view(name = "gold_daily_station_performance")
def gold_daily_station_performance():
  df = dp.read("silver_jc_citybike")\
      .groupBy("trip_start_date", "start_station_name")\
      .agg(
          round(avg("trip_duration_mins"),2).alias("avg_trip_duration_mins"),
          count("ride_id").alias("total_trips")
          )
  return df