# Databricks notebook source
from pyspark import pipelines as dp
from pyspark.sql.functions import *

# COMMAND ----------

@dp.materialized_view(name = "gold_daily_ride_summary")
def gold_daily_ride_summary():
    df = dp.read("silver_jc_citybike")\
         .groupBy("trip_start_date").agg(
         round(max("trip_duration_mins"),2).alias("max_trip_duration_mins"),
         round(min("trip_duration_mins"),2).alias("min_trip_duration_mins"),
         round(avg("trip_duration_mins"),2).alias("avg_trip_duration_mins"),
         count("ride_id").alias("total_trips")
         )
    return df