# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

df = spark.read.table(f"{catalog}.02_silver.jc_citybike")

# COMMAND ----------

df = df.groupBy("trip_start_date").agg(
    round(max("trip_duration_mins"),2).alias("max_trip_duration_mins"),
    round(min("trip_duration_mins"),2).alias("min_trip_duration_mins"),
    round(avg("trip_duration_mins"),2).alias("avg_trip_duration_mins"),
    count("ride_id").alias("total_trips")
)

# COMMAND ----------

df.write\
    .mode("overwrite")\
    .option("overwriteSchema", True)\
    .saveAsTable(f"{catalog}.03_gold.daily_ride_summary")