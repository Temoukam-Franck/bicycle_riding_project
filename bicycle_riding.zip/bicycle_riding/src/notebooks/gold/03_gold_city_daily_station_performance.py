# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

df = spark.read.table(f"{catalog}.02_silver.jc_citybike")

# COMMAND ----------

df = df.groupBy("trip_start_date","start_station_name")\
    .agg(
        round(avg("trip_duration_mins"),2).alias("avg_trip_duration_mins"),
        count("ride_id").alias("total_trips")
    )

# COMMAND ----------

df.write\
    .mode("overwrite")\
    .option("overwriteSchema", True)\
    .saveAsTable(f"{catalog}.03_gold.daily_station_performance")